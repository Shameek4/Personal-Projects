"""Run from any working directory: python /path/to/run.py build."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))


def build():
    from ipl_analytics.data import build_data
    from ipl_analytics.analysis import summarize
    from ipl_analytics.model import build_features, train_and_evaluate
    from ipl_analytics.report import make_report
    print("Loading and validating the source archive...", flush=True)
    m, d, w, i, p, manifest = build_data(ROOT)
    print(f"Loaded {len(m):,} matches and {len(d):,} delivery events.", flush=True)
    tables, summary = summarize(ROOT, m, d, w, i, manifest)
    features = build_features(m, i)
    features.to_csv(ROOT / "data/processed/model_features.csv", index=False)
    print("Training models and evaluating future-season predictions...", flush=True)
    evaluation = train_and_evaluate(ROOT, features)
    report = make_report(ROOT, tables, summary, evaluation)
    print(json.dumps({"data": manifest, "model": evaluation["selected_model"], "test": evaluation["test"],
                      "report": str(report)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description="IPL data, analysis and prediction")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("build", help="Rebuild all analysis from the included source snapshot (offline)")
    sub.add_parser("refresh", help="Download latest source, then rebuild data and analysis")
    p = sub.add_parser("predict", help="Estimate a hypothetical post-toss match using latest history")
    for name in ("team1", "team2", "venue", "toss-winner", "toss-decision"):
        p.add_argument("--" + name, required=True)
    args = parser.parse_args()
    if args.command == "refresh":
        from ipl_analytics.data import download
        download(ROOT)
    if args.command in ("build", "refresh"):
        build()
    else:
        from ipl_analytics.model import predict
        try:
            result = predict(ROOT, args.team1, args.team2, args.venue, args.toss_winner, args.toss_decision)
        except ValueError as error:
            parser.error(str(error))
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
