import copy
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import pytest

from ipl_analytics.data import canonical_team, parse_match, validate
from ipl_analytics.model import build_features, mirrored, probability, predict, FEATURES

ROOT = Path(__file__).resolve().parents[1]


def synthetic_match():
    def ball(runs, extras=None, wickets=None):
        return {"batter": "Batter", "non_striker": "Partner", "bowler": "Bowler",
                "runs": {"batter": runs, "extras": sum((extras or {}).values()), "total": runs+sum((extras or {}).values())},
                "extras": extras or {}, "wickets": wickets or []}
    return {"meta": {"data_version": "1.1.0"}, "info": {
        "gender": "male", "event": {"name": "Indian Premier League"}, "teams": ["A", "B"],
        "dates": ["2020-04-01"], "season": 2020, "balls_per_over": 6,
        "toss": {"winner": "A", "decision": "bat"}, "outcome": {"winner": "B"}},
        "innings": [{"team": "A", "penalty_runs": {"pre": 5}, "overs": [{"over": 0, "deliveries": [
            ball(0, {"wides": 1}), ball(4, {"noballs": 1}), ball(0, {"byes": 2}),
            ball(0, wickets=[{"player_out": "Partner", "kind": "run out"}]),
            ball(0, wickets=[{"player_out": "Batter", "kind": "caught"}]),
            ball(0, wickets=[{"player_out": "Other", "kind": "retired hurt"}]),
        ]}]}, {"team": "B", "super_over": True, "overs": [{"over": 0, "deliveries": [ball(6)]}]}]}


def test_cricket_extras_wickets_and_penalties():
    m, d, w, i, _ = parse_match("1", synthetic_match())
    assert d[0]["legal_ball"] == 0 and d[0]["batter_ball"] == 0
    assert d[1]["legal_ball"] == 0 and d[1]["batter_ball"] == 1
    assert d[1]["bowler_runs"] == 5
    assert d[2]["bowler_runs"] == 0
    assert d[3]["team_wickets"] == 1 and d[3]["bowler_wickets"] == 0
    assert d[4]["bowler_wickets"] == 1
    assert d[5]["team_wickets"] == 0
    assert i[0]["runs"] == 13 and i[0]["legal_balls"] == 4
    assert i[1]["super_over"] and d[-1]["super_over"]
    assert m["city"] == "Unknown"


def test_real_renames_only():
    assert canonical_team("Delhi Daredevils") == "Delhi Capitals"
    assert canonical_team("Deccan Chargers") != canonical_team("Sunrisers Hyderabad")
    assert canonical_team("Pune Warriors") != canonical_team("Rising Pune Supergiant")
    assert canonical_team("Royal Challengers Bangalore") == canonical_team("Royal Challengers Bengaluru")


def test_tie_eliminator_and_multiple_wickets_preserved():
    raw = synthetic_match()
    raw["info"]["outcome"] = {"result": "tie", "eliminator": "A"}
    raw["innings"][0]["overs"][0]["deliveries"][0]["wickets"] = [
        {"player_out": "X", "kind": "run out"}, {"player_out": "Y", "kind": "retired hurt"}]
    m, d, w, _, _ = parse_match("1", raw)
    assert m["winner"] == "A" and m["result"] == "tie"
    assert len([v for v in w if v["delivery_in_over"] == 1]) == 2


def history():
    return pd.DataFrame([
        {"match_id": str(n), "date": date, "season": 2020, "team1": "A", "team2": "B", "venue": "V",
         "winner": "A", "toss_winner": "A", "toss_decision": "bat"}
        for n, date in enumerate(["2020-01-01", "2020-01-01", "2020-01-02", "2020-01-03"])
    ])


def test_no_current_future_or_same_day_outcome_leakage():
    m = history()
    empty_innings = pd.DataFrame(columns=["match_id", "super_over", "legal_balls"])
    original = build_features(m, empty_innings)
    modified = m.copy()
    modified.loc[0, "winner"] = "B"
    changed = build_features(modified, empty_innings)
    pd.testing.assert_frame_equal(original.loc[:1, FEATURES], changed.loc[:1, FEATURES])
    assert changed.loc[2, "elo_diff"] != original.loc[2, "elo_diff"]
    modified = m.copy()
    modified.loc[3, "winner"] = "B"
    changed = build_features(modified, empty_innings)
    pd.testing.assert_frame_equal(original[FEATURES], changed[FEATURES])


def test_scoring_history_uses_only_prior_dates():
    m = history()
    innings = pd.DataFrame([{"match_id": "2", "super_over": False, "legal_balls": 120,
                             "runs": 240, "batting_team": "A"}])
    f = build_features(m, innings)
    assert f.loc[2, "scoring_rate_diff"] == 0
    assert f.loc[3, "scoring_rate_diff"] == 4


def test_full_dataset_integrity():
    m = pd.read_csv(ROOT / "data/processed/matches.csv", keep_default_na=False, dtype={"match_id": str})
    d = pd.read_csv(ROOT / "data/processed/deliveries.csv.gz", dtype={"match_id": str})
    i = pd.read_csv(ROOT / "data/processed/innings.csv", dtype={"match_id": str})
    assert validate(m, d, i)
    assert m.date.min() >= "2008-01-01"


def test_model_symmetry_and_saved_holdout_predictions():
    features = pd.read_csv(ROOT / "data/processed/model_features.csv", dtype={"match_id": str})
    metrics = json.loads((ROOT / "reports/model_metrics.json").read_text())
    model = joblib.load(ROOT / "models/holdout_model.joblib")
    test = features[(features.season == metrics["test_season"]) & features.target.notna()]
    p = probability(model, test)
    np.testing.assert_allclose(p + probability(model, mirrored(test)), 1, atol=1e-12)
    saved = pd.read_csv(ROOT / "reports/test_predictions.csv")
    np.testing.assert_allclose(p, saved.team1_probability, atol=1e-12)
    assert metrics["train_seasons"][-1] < metrics["validation_season"] < metrics["test_season"]


def test_prediction_rejects_invalid_input_and_handles_unseen_venue():
    with pytest.raises(ValueError):
        predict(ROOT, "Mumbai Indians", "Mumbai Indians", "V", "Mumbai Indians", "bat")
    with pytest.raises(ValueError):
        predict(ROOT, "Mumbai Indians", "Chennai Super Kings", "V", "Delhi Capitals", "bat")
    p = predict(ROOT, "Mumbai Indians", "Chennai Super Kings", "Unseen ground", "Mumbai Indians", "bat")
    assert p["unseen_venue"] and 0 <= p["team1_win_probability"] <= 1
    assert p["team1_win_probability"] + p["team2_win_probability"] == pytest.approx(1)
