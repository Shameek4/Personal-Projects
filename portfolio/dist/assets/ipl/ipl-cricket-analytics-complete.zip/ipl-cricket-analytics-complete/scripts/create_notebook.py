"""Recreate the readable analysis notebook; execute it separately to populate outputs."""
from pathlib import Path
import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
nb = nbf.v4.new_notebook()
md = nbf.v4.new_markdown_cell
code = nbf.v4.new_code_cell
nb.cells = [
    md("""# IPL Cricket Analytics & Win Prediction
**Author:** Shameek Vardhan Bhatt

An expanded, reproducible version of the original project. Its README claimed 2008–2019, but the supplied data actually ended in 2016. This notebook rebuilds analysis from the included **Cricsheet** IPL men's JSON snapshot. It covers data validation, team/toss/venue analysis, batting and bowling, scoring phases, historical feature engineering, chronological model evaluation and hypothetical post-toss predictions.

**Read first:** data coverage is the set of matches in the archive, not every official fixture. Original files are preserved in `archive/`. The completed report is `reports/IPL_Analytics_Report.html`.

Data: [Cricsheet / Stephen Rushe](https://cricsheet.org/downloads/), [ODC-By 1.0](https://cricsheet.org/licensing/). Changes include normalized names and derived analytical tables. See `docs/METHODOLOGY.md` for assumptions and limitations."""),
    md("## 1. Environment and project paths\nRun from the project directory with the dependencies in `requirements.txt`. No internet is needed when using the included raw snapshot."),
    code("""from pathlib import Path
import sys, json
import pandas as pd
from IPython.display import display, Image, Markdown

ROOT = Path.cwd().resolve()
if not (ROOT / 'src/ipl_analytics').exists():
    raise RuntimeError('Start Jupyter from the project directory.')
sys.path.insert(0, str(ROOT / 'src'))
from ipl_analytics.data import build_data, validate
from ipl_analytics.analysis import summarize
from ipl_analytics.model import build_features, train_and_evaluate, predict, FEATURES
from ipl_analytics.report import make_report
pd.set_option('display.max_columns', 30)
"""),
    md("## 2. Load and validate the source\nThe parser creates tables at five grains: matches, deliveries, wickets, innings and player appearances. It checks unique keys, participant consistency, extras arithmetic and innings totals. Super Overs and no-result matches are retained with explicit flags."),
    code("""matches, deliveries, wickets, innings, players, manifest = build_data(ROOT)
display(pd.Series(manifest, name='Snapshot'))
display(matches.head())
print('Integrity validation:', validate(matches, deliveries, innings))
"""),
    code("""display(matches.groupby('season').agg(matches=('match_id','size'), first_date=('date','min'), last_date=('date','max')))
display(matches[['city','winner','method','missing_info']].apply(lambda c: c.value_counts()).fillna(0).head(15))
"""),
    md("## 3. Normalize franchises without merging distinct teams\nActual name changes are consolidated: Delhi, Punjab, Bengaluru and the singular/plural Rising Pune spelling. **Deccan Chargers ≠ Sunrisers Hyderabad; Pune Warriors ≠ Rising Pune Supergiant.** Missing cities remain Unknown. Raw labels remain in the source/processed data. Team 1 is alphabetically ordered, not automatically the home team."),
    code("""from ipl_analytics.data import TEAM_ALIASES
display(pd.Series(TEAM_ALIASES, name='Canonical franchise'))
print('Missing cities:', matches.city.eq('Unknown').sum())
print('Matches without a winner:', matches.winner.eq('').sum())
"""),
    md("## 4. Descriptive analysis\nAll source matches contribute to coverage. Decided outcomes drive win percentages. Chasing comparisons exclude ties/Super Overs and results with a recorded rain-adjustment method. These relationships are descriptive, not causal."),
    code("""tables, summary = summarize(ROOT, matches, deliveries, wickets, innings, manifest)
display(tables['team_summary'])
display(tables['toss_summary'])
display(tables['venue_summary'].head(10))
print('Legacy reconciliation:', summary['reconciliation'])
"""),
    md("## 5. Player analysis from ball-by-ball records\nPlayer IDs keep identity stable across spelling changes. Career and season tables exclude Super Overs. Batting balls exclude wides; bowling balls exclude wides and no-balls. Bowler runs exclude byes, leg-byes and penalties. Run outs and retirements are not credited to the bowler. A zero dismissal/wicket denominator gives a blank average."),
    code("""display(tables['batting_career'].head(15))
display(tables['bowling_career'].head(15))
latest = matches.season.max()
display(tables['batting_season'].query('season == @latest').head(10))
display(tables['bowling_season'].query('season == @latest').head(10))
"""),
    md("## 6. Phase and scoring trends\nFixed bands use overs 1–6, 7–15 and 16–20. They are not reduced-match powerplay reconstructions. First-innings scoring trends use unreduced, scheduled 20-over innings reaching 120 legal balls or ten wickets."),
    code("""display(tables['phase_summary'])
display(tables['first_innings_trend'])
display(tables['season_champions'])
"""),
    md("## 7. Features available before play, after the toss\nOnly earlier dates contribute Elo ratings, recent win/scoring form, experience and head-to-head results. Rows for an entire date are created before updating history, preventing same-day leakage. Current scores, awards, margins and winners are not feature inputs."),
    code("""features = build_features(matches, innings)
features.to_csv(ROOT / 'data/processed/model_features.csv', index=False)
display(features[['date','team1','team2', *[c for c in FEATURES if c not in ('team1','team2')], 'target']].tail())
assert not {'winner','win_by_runs','win_by_wickets','player_of_match'} & set(FEATURES)
"""),
    md("## 8. Chronological evaluation\nEarlier seasons train the models, the penultimate season selects between logistic regression and random forest by log loss, and the latest season is held out. The chosen model is refitted before the test season. History updates after earlier test dates; model weights do not. Mirrored team-order training and symmetric inference prevent ordering bias. The training-prior baseline uses training labels only."),
    code("""evaluation = train_and_evaluate(ROOT, features)
display(pd.DataFrame(evaluation['validation_candidates']))
display(pd.DataFrame({'Selected model': evaluation['test'], 'Training-prior baseline': evaluation['baseline_test'], 'Coin-flip probability': evaluation['coin_flip_test']}))
print('Selected model:', evaluation['selected_model'])
print('Train seasons:', evaluation['train_seasons'])
print('Validation:', evaluation['validation_season'], 'Test:', evaluation['test_season'])
print(evaluation['protocol'])
"""),
    md("## 9. Generate report and inspect charts\nAll narrative numbers come from this execution. The HTML report embeds its charts and can be opened without internet or Python."),
    code("""report_path = make_report(ROOT, tables, summary, evaluation)
print(report_path.relative_to(ROOT))
display(Markdown((ROOT / 'reports/FINDINGS.md').read_text(encoding='utf-8')))
"""),
    code("""for name in ['season_coverage','team_wins_barh','batting_barh','bowling_barh','scoring_trend','phase_scoring','confusion_matrix','calibration']:
    display(Image(filename=str(ROOT / 'reports/charts' / f'{name}.png'), width=850))
"""),
    md("## 10. Hypothetical post-toss forecast\nThis example uses history through the latest source date and the model refitted on all decided matches. It is not a replay of a historical forecast. Actual line-ups, injuries, weather and pitch measurements are not included. Unknown venues are flagged, while invalid teams/toss inputs raise clear errors."),
    code("""predict(ROOT, team1='Mumbai Indians', team2='Chennai Super Kings',
        venue='Wankhede Stadium', toss_winner='Mumbai Indians', toss_decision='field')
"""),
    md("## 11. Reproducibility and conclusions\nRun `python -m pytest -q` from the project folder for data and prediction checks. `python run.py build` rebuilds offline; `python run.py refresh` downloads a new source snapshot and rebuilds. A refresh may change coverage, train/validation/test seasons and measured performance.\n\nThe final model should be compared with the baseline using both classification and probability metrics. One held-out season is a limited evaluation, and aggregate historical advantages cannot establish causality. Future improvements should be independently evaluated: roster-aware form, weather/pitch information and rolling-season backtests.\n\nFull definitions: `docs/DATA_DICTIONARY.md` and `docs/METHODOLOGY.md`."),
]
nb.metadata = {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
               "language_info": {"name": "python", "version": "3.12"}}
nbf.write(nb, ROOT / "IPL_Cricket_Analytics.ipynb")
print(f"Created notebook with {len(nb.cells)} cells")
