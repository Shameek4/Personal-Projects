"""Execute this Python-only notebook in-process, including rich display outputs.

Useful on desktops where local Jupyter kernel sockets are restricted.
For ordinary Jupyter usage, opening and running the notebook also works.
"""
import os
from pathlib import Path

import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
path = ROOT / "IPL_Cricket_Analytics.ipynb"
nb = nbformat.read(path, as_version=4)
shell = InteractiveShell.instance()
count = 0
for cell in nb.cells:
    if cell.cell_type != "code":
        continue
    count += 1
    print(f"Executing code cell {count}", flush=True)
    with capture_output() as captured:
        result = shell.run_cell(cell.source, store_history=False)
    if result.error_before_exec or result.error_in_exec:
        raise RuntimeError(f"Cell {count} failed") from (result.error_before_exec or result.error_in_exec)
    cell.execution_count = count
    cell.outputs = []
    if captured.stdout:
        cell.outputs.append(nbformat.v4.new_output("stream", name="stdout", text=captured.stdout))
    if captured.stderr:
        cell.outputs.append(nbformat.v4.new_output("stream", name="stderr", text=captured.stderr))
    for item in captured.outputs:
        cell.outputs.append(nbformat.v4.new_output("display_data", data=item.data, metadata=item.metadata))
nbformat.validate(nb)
nbformat.write(nb, path)
print(f"Executed {count} code cells successfully: {path.name}")
