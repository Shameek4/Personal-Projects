"""Post-toss prediction with strictly earlier-date features and season holdouts."""
from __future__ import annotations

from collections import defaultdict, deque
import json
import math
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss, roc_auc_score, confusion_matrix
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .data import canonical_team, VENUE_ALIASES

CATEGORICAL = ["team1", "team2", "venue"]
DIFFERENCES = ["elo_diff", "form_diff", "h2h_diff", "scoring_rate_diff", "experience_diff"]
NUMERIC = ["toss_team1", "team1_bats_first"] + DIFFERENCES
FEATURES = CATEGORICAL + NUMERIC


def build_features(matches, innings):
    """Make every day's rows before updating state with that day's results."""
    ratings = defaultdict(lambda: 1500.0)
    form = defaultdict(lambda: deque(maxlen=10))
    scoring = defaultdict(lambda: deque(maxlen=10))
    experience = defaultdict(int)
    h2h = defaultdict(lambda: [0, 0])
    innings_map = defaultdict(list)
    for row in innings.to_dict("records"):
        if not row["super_over"] and row["legal_balls"] > 0:
            innings_map[str(row["match_id"])].append(row)
    rows = []
    for _, day in matches.sort_values(["date", "match_id"]).groupby("date", sort=True):
        updates = []
        for match in day.to_dict("records"):
            a, b = match["team1"], match["team2"]
            games, wins = h2h[(a, b)]
            # Neutral priors keep a new franchise usable without merging its history.
            rate = lambda t: sum(v[0] for v in scoring[t]) * 6 / sum(v[1] for v in scoring[t]) if scoring[t] else 8.0
            record = {"match_id": str(match["match_id"]), "date": match["date"], "season": match["season"],
                      "team1": a, "team2": b, "venue": match["venue"],
                      "toss_team1": int(match["toss_winner"] == a),
                      "team1_bats_first": int((match["toss_winner"] == a) == (match["toss_decision"] == "bat")),
                      "elo_diff": ratings[a] - ratings[b],
                      "form_diff": (np.mean(form[a]) if form[a] else .5) - (np.mean(form[b]) if form[b] else .5),
                      "h2h_diff": 2 * (wins + 2) / (games + 4) - 1,
                      "scoring_rate_diff": rate(a) - rate(b),
                      "experience_diff": math.log1p(experience[a]) - math.log1p(experience[b]),
                      "target": int(match["winner"] == a) if match["winner"] in (a, b) else np.nan}
            rows.append(record)
            if match["winner"] in (a, b):
                actual = float(match["winner"] == a)
                expected = 1 / (1 + 10 ** ((ratings[b] - ratings[a]) / 400))
                updates.append((a, b, actual, 20 * (actual - expected)))
        for a, b, actual, change in updates:
            ratings[a] += change
            ratings[b] -= change
            for team, outcome in ((a, actual), (b, 1 - actual)):
                form[team].append(outcome)
                experience[team] += 1
            h2h[(a, b)][0] += 1
            h2h[(a, b)][1] += actual
            h2h[(b, a)][0] += 1
            h2h[(b, a)][1] += 1 - actual
        for match in day.to_dict("records"):
            # Scoring from unfinished matches is not used as a form observation.
            if match["winner"] in (match["team1"], match["team2"]):
                for inn in innings_map[str(match["match_id"])]:
                    scoring[inn["batting_team"]].append((inn["runs"], inn["legal_balls"]))
    return pd.DataFrame(rows)


def mirrored(frame):
    result = frame.copy()
    result["team1"], result["team2"] = frame.team2, frame.team1
    for name in ["toss_team1", "team1_bats_first"]:
        result[name] = 1 - result[name]
    result[DIFFERENCES] = -result[DIFFERENCES]
    if "target" in result:
        result["target"] = 1 - result["target"]
    return result


def make_pipeline(kind):
    pre = ColumnTransformer([
        ("categories", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL),
        ("numeric", StandardScaler(), NUMERIC),
    ])
    estimator = (LogisticRegression(C=.15, max_iter=2000, random_state=42) if kind == "Logistic regression"
                 else RandomForestClassifier(n_estimators=250, max_depth=5, min_samples_leaf=12,
                                             max_features=.8, n_jobs=-1, random_state=42))
    return Pipeline([("preprocess", pre), ("model", estimator)])


def fit_model(kind, train):
    both = pd.concat([train, mirrored(train)], ignore_index=True)
    return make_pipeline(kind).fit(both[FEATURES], both.target.astype(int))


def probability(model, frame):
    # Symmetrization makes swapping team order exactly complement probabilities.
    return (model.predict_proba(frame[FEATURES])[:, 1] + 1 -
            model.predict_proba(mirrored(frame)[FEATURES])[:, 1]) / 2


def metrics(y, p):
    y = np.asarray(y, dtype=int)
    p = np.clip(np.asarray(p), 1e-8, 1 - 1e-8)
    accuracy = accuracy_score(y, p >= .5)
    n, z = len(y), 1.96
    centre = (accuracy + z*z/(2*n)) / (1 + z*z/n)
    half = z * math.sqrt(accuracy*(1-accuracy)/n + z*z/(4*n*n)) / (1 + z*z/n)
    return {"matches": n, "accuracy": float(accuracy), "log_loss": float(log_loss(y, p, labels=[0, 1])),
            "brier_score": float(brier_score_loss(y, p)),
            "roc_auc": float(roc_auc_score(y, p)) if len(set(y)) == 2 else None,
            "accuracy_ci95_low": centre-half, "accuracy_ci95_high": centre+half}


def train_and_evaluate(root, features):
    eligible = features.dropna(subset=["target"]).copy()
    seasons = sorted(eligible.season.unique())
    if len(seasons) < 3:
        raise ValueError("At least three seasons are required for time-based evaluation")
    validation_season, test_season = int(seasons[-2]), int(seasons[-1])
    train = eligible[eligible.season < validation_season]
    validation = eligible[eligible.season == validation_season]
    test = eligible[eligible.season == test_season]
    records = []
    for kind in ("Logistic regression", "Random forest"):
        estimator = fit_model(kind, train)
        records.append({"model": kind, **metrics(validation.target, probability(estimator, validation))})
    chosen = min(records, key=lambda r: r["log_loss"])["model"]
    train_and_validation = eligible[eligible.season < test_season]
    holdout_model = fit_model(chosen, train_and_validation)
    p = probability(holdout_model, test)
    prior = float(train_and_validation.target.mean())
    baseline_p = np.full(len(test), prior)
    evaluation = {
        "selected_model": chosen, "selection_metric": "lowest validation log loss",
        "train_seasons": [int(s) for s in seasons[:-2]], "validation_season": validation_season,
        "test_season": test_season, "validation_candidates": records,
        "test": metrics(test.target, p), "baseline_training_prior": prior,
        "baseline_test": metrics(test.target, baseline_p),
        "coin_flip_test": metrics(test.target, np.full(len(test), .5)),
        "confusion_matrix": confusion_matrix(test.target, p >= .5, labels=[0, 1]).tolist(),
        "protocol": "Model weights fixed before the test season. History features update after each date; only earlier dates are available. This simulates post-toss match-by-match forecasts, not preseason forecasts.",
        "final_model_note": "Deployment model refitted on all decided matches after evaluation; test metrics describe the earlier holdout model, not this refit.",
        "feature_columns": FEATURES,
    }
    predictions = test[["match_id", "date", "season", "team1", "team2", "target"]].copy()
    predictions["team1_probability"] = p
    predictions["predicted_winner"] = np.where(p >= .5, test.team1, test.team2)
    predictions["correct"] = (p >= .5) == test.target
    reports = root / "reports"
    reports.mkdir(exist_ok=True)
    predictions.to_csv(reports / "test_predictions.csv", index=False)
    pd.DataFrame(records).to_csv(reports / "validation_metrics.csv", index=False)
    (reports / "model_metrics.json").write_text(json.dumps(evaluation, indent=2), encoding="utf-8")
    final_model = fit_model(chosen, eligible)
    joblib.dump({"pipeline": final_model, "selected_model": chosen,
                 "trained_through": str(eligible.date.max()), "features": FEATURES}, root / "models/win_model.joblib")
    # Keep the evaluated model separately so every saved test prediction is reproducible.
    joblib.dump(holdout_model, root / "models/holdout_model.joblib")
    names = final_model.named_steps["preprocess"].get_feature_names_out()
    estimator = final_model.named_steps["model"]
    values = estimator.coef_[0] if hasattr(estimator, "coef_") else estimator.feature_importances_
    pd.DataFrame({"feature": names, "value": values}).to_csv(reports / "model_parameters.csv", index=False)
    return evaluation


def predict(root: Path, team1: str, team2: str, venue: str, toss_winner: str, toss_decision: str):
    m = pd.read_csv(root / "data/processed/matches.csv", keep_default_na=False, dtype={"match_id": str})
    i = pd.read_csv(root / "data/processed/innings.csv", dtype={"match_id": str})
    team1, team2, toss_winner = map(canonical_team, (team1, team2, toss_winner))
    known = set(m.team1) | set(m.team2)
    if team1 == team2 or team1 not in known or team2 not in known:
        raise ValueError("Choose two different teams present in the historical dataset")
    if toss_winner not in (team1, team2) or toss_decision not in ("bat", "field"):
        raise ValueError("Toss winner must be a participant; toss decision must be bat or field")
    if not venue.strip():
        raise ValueError("Venue must be supplied")
    venue = VENUE_ALIASES.get(venue, venue)
    after = (pd.Timestamp(m.date.max()) + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
    hypothetical = {"match_id": "hypothetical", "date": after, "season": int(after[:4]),
                    "team1": team1, "team2": team2, "venue": venue, "winner": "",
                    "toss_winner": toss_winner, "toss_decision": toss_decision}
    features = build_features(pd.concat([m, pd.DataFrame([hypothetical])], ignore_index=True), i).tail(1)
    artifact = joblib.load(root / "models/win_model.joblib")
    p = float(probability(artifact["pipeline"], features)[0])
    return {"team1": team1, "team2": team2, "team1_win_probability": round(p, 4),
            "team2_win_probability": round(1-p, 4), "history_through": str(m.date.max()),
            "unseen_venue": venue not in set(m.venue), "model": artifact["selected_model"],
            "note": "Experimental post-toss estimate using latest available history; excludes line-ups, injuries and weather. Historical franchises remain available for hypothetical comparisons."}
