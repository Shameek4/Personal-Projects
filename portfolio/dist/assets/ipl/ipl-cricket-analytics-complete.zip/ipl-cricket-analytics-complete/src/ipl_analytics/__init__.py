"""Reproducible IPL analytics using attributed Cricsheet data."""
