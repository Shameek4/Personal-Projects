"""Download, normalize and validate the Cricsheet IPL JSON archive."""
from __future__ import annotations

import hashlib
import json
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

SOURCE_URL = "https://cricsheet.org/downloads/ipl_male_json.zip"
TEAM_ALIASES = {
    "Delhi Daredevils": "Delhi Capitals",
    "Kings XI Punjab": "Punjab Kings",
    "Royal Challengers Bangalore": "Royal Challengers Bengaluru",
    "Rising Pune Supergiants": "Rising Pune Supergiant",
}
VENUE_ALIASES = {
    "M Chinnaswamy Stadium, Bengaluru": "M Chinnaswamy Stadium",
    "M.Chinnaswamy Stadium": "M Chinnaswamy Stadium",
    "MA Chidambaram Stadium, Chepauk, Chennai": "MA Chidambaram Stadium",
    "MA Chidambaram Stadium, Chepauk": "MA Chidambaram Stadium",
    "Wankhede Stadium, Mumbai": "Wankhede Stadium",
    "Eden Gardens, Kolkata": "Eden Gardens",
    "Arun Jaitley Stadium, Delhi": "Arun Jaitley Stadium",
    "Feroz Shah Kotla": "Arun Jaitley Stadium",
    "Feroz Shah Kotla, Delhi": "Arun Jaitley Stadium",
    "Punjab Cricket Association Stadium, Mohali": "PCA IS Bindra Stadium, Mohali",
    "Punjab Cricket Association IS Bindra Stadium, Mohali": "PCA IS Bindra Stadium, Mohali",
    "Punjab Cricket Association IS Bindra Stadium": "PCA IS Bindra Stadium, Mohali",
    "Rajiv Gandhi International Stadium, Uppal": "Rajiv Gandhi International Stadium",
    "Rajiv Gandhi International Stadium, Uppal, Hyderabad": "Rajiv Gandhi International Stadium",
    "Sawai Mansingh Stadium, Jaipur": "Sawai Mansingh Stadium",
    "Maharashtra Cricket Association Stadium, Pune": "Maharashtra Cricket Association Stadium",
    "Dr DY Patil Sports Academy, Mumbai": "Dr DY Patil Sports Academy",
    "Brabourne Stadium, Mumbai": "Brabourne Stadium",
    "Narendra Modi Stadium, Ahmedabad": "Narendra Modi Stadium",
    "Sardar Patel Stadium, Motera": "Narendra Modi Stadium",
    "Punjab Cricket Association IS Bindra Stadium, Mohali, Chandigarh": "PCA IS Bindra Stadium, Mohali",
    "Himachal Pradesh Cricket Association Stadium, Dharamsala": "Himachal Pradesh Cricket Association Stadium",
    "Dr. Y.S. Rajasekhara Reddy ACA-VDCA Cricket Stadium, Visakhapatnam": "Dr. Y.S. Rajasekhara Reddy ACA-VDCA Cricket Stadium",
    "Shaheed Veer Narayan Singh International Stadium, Raipur": "Shaheed Veer Narayan Singh International Stadium",
}
NON_BOWLER_WICKETS = {"run out", "retired hurt", "obstructing the field", "retired out"}


def canonical_team(name):
    return TEAM_ALIASES.get(name, name)


def download(root: Path):
    dest = root / "data/raw/ipl_male_json.zip"
    dest.parent.mkdir(parents=True, exist_ok=True)
    temporary = dest.with_suffix(".download")
    request = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "IPL-Analytics/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response, temporary.open("wb") as out:
        while chunk := response.read(1024 * 1024):
            out.write(chunk)
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() or not any(n.endswith(".json") for n in archive.namelist()):
            raise ValueError("Downloaded archive is invalid")
    temporary.replace(dest)
    (dest.parent / "download_receipt.json").write_text(json.dumps({
        "downloaded_at_utc": datetime.now(timezone.utc).isoformat(), "url": SOURCE_URL,
        "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
    }, indent=2), encoding="utf-8")


def parse_match(match_id, raw):
    info = raw["info"]
    if info["gender"] != "male" or info["event"]["name"] != "Indian Premier League":
        raise ValueError(f"Unexpected competition in {match_id}")
    people = info.get("registry", {}).get("people", {})
    teams_raw = info["teams"]
    # Alphabetic order is stable and is independent of the toss and eventual result.
    teams = sorted(canonical_team(t) for t in teams_raw)
    outcome = info["outcome"]
    winner = canonical_team(outcome.get("winner") or outcome.get("eliminator") or outcome.get("bowl_out") or "")
    toss = info.get("toss", {})
    date = str(info["dates"][0])
    row = {
        "match_id": str(match_id), "date": date, "season": int(date[:4]),
        "season_raw": str(info["season"]), "team1": teams[0], "team2": teams[1],
        "team1_raw": teams_raw[0], "team2_raw": teams_raw[1],
        "city": {"Bangalore": "Bengaluru"}.get(info.get("city"), info.get("city", "Unknown")),
        "venue": VENUE_ALIASES.get(info.get("venue"), info.get("venue", "Unknown")),
        "venue_raw": info.get("venue", "Unknown"),
        "toss_winner": canonical_team(toss.get("winner", "")), "toss_decision": toss.get("decision", ""),
        "winner": winner, "result": outcome.get("result", "normal" if winner else "unknown"),
        "method": outcome.get("method", ""), "win_by_runs": outcome.get("by", {}).get("runs", 0),
        "win_by_wickets": outcome.get("by", {}).get("wickets", 0),
        "player_of_match": " | ".join(info.get("player_of_match", [])),
        "stage": info.get("event", {}).get("stage", "League"),
        "scheduled_overs": info.get("overs", 20), "balls_per_over": info["balls_per_over"],
        "missing_info": json.dumps(info.get("missing", [])),
        "data_version": raw["meta"]["data_version"],
    }
    balls, wickets, innings_rows, players = [], [], [], []
    for team, names in info.get("players", {}).items():
        for name in names:
            players.append({"match_id": str(match_id), "season": int(date[:4]),
                            "team": canonical_team(team), "player": name,
                            "player_id": people.get(name, name)})
    for inn_no, inn in enumerate(raw.get("innings", []), 1):
        batting = canonical_team(inn["team"])
        bowling = next(t for t in teams if t != batting)
        super_over = bool(inn.get("super_over", False))
        inn_balls = []
        for over in inn.get("overs", []):
            for sequence, ball in enumerate(over["deliveries"], 1):
                extras = ball.get("extras", {})
                wk = ball.get("wickets", [])
                delivery = {
                    "match_id": str(match_id), "season": int(date[:4]), "innings": inn_no,
                    "super_over": super_over, "over": over["over"], "delivery_in_over": sequence,
                    "batting_team": batting, "bowling_team": bowling,
                    "batter": ball["batter"], "batter_id": people.get(ball["batter"], ball["batter"]),
                    "bowler": ball["bowler"], "bowler_id": people.get(ball["bowler"], ball["bowler"]),
                    "non_striker": ball["non_striker"], "batter_runs": ball["runs"]["batter"],
                    "extra_runs": ball["runs"]["extras"], "total_runs": ball["runs"]["total"],
                    **{k: extras.get(k, 0) for k in ("wides", "noballs", "byes", "legbyes", "penalty")},
                    "legal_ball": int(not extras.get("wides") and not extras.get("noballs")),
                    "batter_ball": int(not extras.get("wides")),
                    "bowler_runs": ball["runs"]["batter"] + extras.get("wides", 0) + extras.get("noballs", 0),
                    "team_wickets": sum(w["kind"] != "retired hurt" for w in wk),
                    "bowler_wickets": sum(w["kind"] not in NON_BOWLER_WICKETS for w in wk),
                    "four": int(ball["runs"]["batter"] == 4 and not ball["runs"].get("non_boundary", False)),
                    "six": int(ball["runs"]["batter"] == 6 and not ball["runs"].get("non_boundary", False)),
                    "phase": "Powerplay (1-6)" if over["over"] < 6 else "Middle (7-15)" if over["over"] < 15 else "Death (16-20)",
                }
                balls.append(delivery)
                inn_balls.append(delivery)
                for wi, w in enumerate(wk):
                    wickets.append({"match_id": str(match_id), "season": int(date[:4]), "innings": inn_no,
                                    "super_over": super_over, "over": over["over"], "delivery_in_over": sequence,
                                    "wicket_index": wi, "player_out": w["player_out"],
                                    "player_id": people.get(w["player_out"], w["player_out"]),
                                    "kind": w["kind"], "bowler": ball["bowler"],
                                    "credited_to_bowler": w["kind"] not in NON_BOWLER_WICKETS})
        penalty = inn.get("penalty_runs", {})
        innings_rows.append({"match_id": str(match_id), "season": int(date[:4]), "innings": inn_no,
                             "super_over": super_over, "batting_team": batting, "bowling_team": bowling,
                             "runs": sum(d["total_runs"] for d in inn_balls) + sum(penalty.values()),
                             "penalty_pre": penalty.get("pre", 0), "penalty_post": penalty.get("post", 0),
                             "legal_balls": sum(d["legal_ball"] for d in inn_balls),
                             "wickets": sum(d["team_wickets"] for d in inn_balls),
                             "target_runs": inn.get("target", {}).get("runs"),
                             "target_overs": inn.get("target", {}).get("overs")})
    normal = [i for i in innings_rows if not i["super_over"]]
    row["batting_first"] = normal[0]["batting_team"] if normal else ""
    row["chasing_team"] = next((t for t in teams if t != row["batting_first"]), "") if normal else ""
    row["has_super_over"] = any(i["super_over"] for i in innings_rows)
    return row, balls, wickets, innings_rows, players


def build_data(root):
    archive_path = root / "data/raw/ipl_male_json.zip"
    containers = [[] for _ in range(5)]
    with zipfile.ZipFile(archive_path) as archive:
        for name in sorted(archive.namelist()):
            if name.endswith(".json"):
                parts = parse_match(Path(name).stem, json.loads(archive.read(name)))
                containers[0].append(parts[0])
                for target, rows in zip(containers[1:], parts[1:]):
                    target.extend(rows)
            elif Path(name).name.lower().startswith(("readme", "license")):
                (root / "data/raw" / Path(name).name).write_bytes(archive.read(name))
    m, d, w, i, p = [pd.DataFrame(rows) for rows in containers]
    m = m.sort_values(["date", "match_id"]).reset_index(drop=True)
    validate(m, d, i)
    out = root / "data/processed"
    out.mkdir(parents=True, exist_ok=True)
    for name, frame in [("matches", m), ("deliveries", d), ("wickets", w), ("innings", i), ("players", p)]:
        frame.to_csv(out / (name + (".csv.gz" if name == "deliveries" else ".csv")), index=False,
                     compression={"method": "gzip", "mtime": 0} if name == "deliveries" else None)
    manifest = {
        "source": "Cricsheet / Stephen Rushe", "url": SOURCE_URL,
        "license": "Open Data Commons Attribution License (ODC-By) 1.0",
        "license_url": "https://opendatacommons.org/licenses/by/1-0/",
        "source_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
        "coverage_start": m.date.min(), "coverage_end": m.date.max(),
        "seasons": sorted(m.season.unique().tolist()),
        "matches": len(m), "delivery_events": len(d), "super_over_deliveries": int(d.super_over.sum()),
        "matches_without_winner": int(m.winner.eq("").sum()), "missing_cities": int(m.city.eq("Unknown").sum()),
        "coverage_note": "Matches present in the downloaded archive; not a complete official fixture list. Unplayed/abandoned fixtures may be absent.",
    }
    receipt = root / "data/raw/download_receipt.json"
    if receipt.exists():
        manifest.update(json.loads(receipt.read_text(encoding="utf-8")))
    (root / "data/source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return m, d, w, i, p, manifest


def validate(m, d, innings):
    def check(condition, message):
        if not condition:
            raise ValueError(message)
    check(m.match_id.is_unique, "Duplicate match IDs")
    check((m.team1 != m.team2).all(), "Identical opponent teams")
    check(((m.winner == "") | (m.winner == m.team1) | (m.winner == m.team2)).all(), "Winner not a participant")
    check(((m.toss_winner == m.team1) | (m.toss_winner == m.team2)).all(), "Toss winner not a participant")
    check(set(d.match_id) <= set(m.match_id), "Orphan deliveries")
    check(~d.duplicated(["match_id", "innings", "over", "delivery_in_over"]).any(), "Duplicate delivery keys")
    check((d.batter_runs + d.extra_runs == d.total_runs).all(), "Run reconciliation failed")
    check((d[["wides", "noballs", "byes", "legbyes", "penalty"]].sum(axis=1) == d.extra_runs).all(), "Extras reconciliation failed")
    check((d.bowler_wickets <= d.team_wickets).all(), "Invalid wicket credit")
    sums = d.groupby(["match_id", "innings"]).total_runs.sum()
    expected = innings.set_index(["match_id", "innings"])
    check((sums.reindex(expected.index, fill_value=0) + expected.penalty_pre + expected.penalty_post == expected.runs).all(), "Innings reconciliation failed")
    return True
