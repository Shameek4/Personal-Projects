"""Player, team and season statistics with explicit cricket denominators."""
import json

import numpy as np
import pandas as pd


def batting_table(deliveries, wickets, by_season=False):
    d = deliveries[~deliveries.super_over].copy()
    keys = (["season"] if by_season else []) + ["batter_id"]
    result = d.groupby(keys).agg(player=("batter", "last"), runs=("batter_runs", "sum"),
                                 balls=("batter_ball", "sum"), fours=("four", "sum"), sixes=("six", "sum"))
    innings = d.drop_duplicates(keys + ["match_id", "innings"]).groupby(keys).size()
    result["innings_with_delivery"] = innings
    outs = wickets[(~wickets.super_over) & (wickets.kind != "retired hurt")].rename(columns={"player_id": "batter_id"})
    result["dismissals"] = outs.groupby(keys).size().reindex(result.index, fill_value=0)
    result["strike_rate"] = (result.runs / result.balls.replace(0, np.nan) * 100).round(2)
    result["average"] = (result.runs / result.dismissals.replace(0, np.nan)).round(2)
    scores = d.groupby(keys + ["match_id", "innings"]).batter_runs.sum()
    result["highest_score"] = scores.groupby(level=list(range(len(keys)))).max()
    return result.reset_index().rename(columns={"batter_id": "player_id"}).sort_values("runs", ascending=False)


def bowling_table(deliveries, by_season=False):
    d = deliveries[~deliveries.super_over]
    keys = (["season"] if by_season else []) + ["bowler_id"]
    result = d.groupby(keys).agg(player=("bowler", "last"), wickets=("bowler_wickets", "sum"),
                                 legal_balls=("legal_ball", "sum"), conceded=("bowler_runs", "sum"))
    result["innings"] = d.drop_duplicates(keys + ["match_id", "innings"]).groupby(keys).size()
    result["economy"] = (result.conceded * 6 / result.legal_balls.replace(0, np.nan)).round(2)
    result["average"] = (result.conceded / result.wickets.replace(0, np.nan)).round(2)
    result["strike_rate"] = (result.legal_balls / result.wickets.replace(0, np.nan)).round(2)
    return result.reset_index().rename(columns={"bowler_id": "player_id"}).sort_values(["wickets", "economy"], ascending=[False, True])


def summarize(root, matches, deliveries, wickets, innings, manifest):
    tables = {}
    decided = matches[matches.winner != ""].copy()
    tables["season_summary"] = matches.groupby("season").agg(matches=("match_id", "size"),
                                                            start_date=("date", "min"), end_date=("date", "max"))
    tables["season_summary"]["decided"] = decided.groupby("season").size()
    tables["season_summary"]["no_winner"] = tables["season_summary"].matches - tables["season_summary"].decided
    tables["season_summary"] = tables["season_summary"].reset_index()
    appearances = pd.concat([matches.assign(team=matches.team1), matches.assign(team=matches.team2)])
    appearances["win"] = appearances.team == appearances.winner
    appearances["decided"] = appearances.winner != ""
    appearances["no_result"] = appearances.winner == ""
    team = appearances.groupby("team").agg(played=("match_id", "size"), wins=("win", "sum"),
                                           decided=("decided", "sum"), without_winner=("no_result", "sum"))
    team["win_pct_decided"] = (100 * team.wins / team.decided).round(2)
    tables["team_summary"] = team.sort_values("wins", ascending=False).reset_index()
    tables["batting_career"] = batting_table(deliveries, wickets)
    tables["batting_season"] = batting_table(deliveries, wickets, True)
    tables["bowling_career"] = bowling_table(deliveries)
    tables["bowling_season"] = bowling_table(deliveries, True)
    regulation = decided[(decided.method == "") & (decided.result == "normal") & (~decided.has_super_over) & (decided.batting_first != "")].copy()
    regulation["chase_win"] = regulation.winner == regulation.chasing_team
    venues = regulation.groupby("venue").agg(matches=("match_id", "size"), chase_wins=("chase_win", "sum"))
    venues["chase_win_pct"] = (100 * venues.chase_wins / venues.matches).round(2)
    tables["venue_summary"] = venues.sort_values("matches", ascending=False).reset_index()
    decided["toss_match_win"] = decided.toss_winner == decided.winner
    toss = decided.groupby("toss_decision").agg(matches=("match_id", "size"), toss_winner_wins=("toss_match_win", "sum"))
    toss["win_pct"] = (100 * toss.toss_winner_wins / toss.matches).round(2)
    tables["toss_summary"] = toss.reset_index()
    # Fixed over bands only on unreduced, 20-over matches; this is not a rain-adjusted powerplay metric.
    full_ids = set(matches[(matches.scheduled_overs == 20) & (matches.method == "")].match_id)
    phase = deliveries[(~deliveries.super_over) & deliveries.match_id.isin(full_ids)].groupby("phase").agg(
        runs=("total_runs", "sum"), legal_balls=("legal_ball", "sum"), wickets=("team_wickets", "sum"),
        fours=("four", "sum"), sixes=("six", "sum"))
    phase["run_rate"] = (phase.runs * 6 / phase.legal_balls).round(2)
    tables["phase_summary"] = phase.reindex(["Powerplay (1-6)", "Middle (7-15)", "Death (16-20)"]).reset_index()
    normal_i = innings[(~innings.super_over) & (innings.innings == 1)].merge(matches[["match_id", "method", "scheduled_overs"]], on="match_id")
    # Include all-outs but exclude innings that stopped before the end without being all out.
    complete_first = normal_i[(normal_i.method == "") & (normal_i.scheduled_overs == 20) &
                              ((normal_i.legal_balls >= 120) | (normal_i.wickets >= 10))]
    tables["first_innings_trend"] = complete_first.groupby("season").agg(innings=("runs", "size"), average_runs=("runs", "mean")).round(2).reset_index()
    tables["season_champions"] = matches[(matches.stage.str.lower() == "final") & (matches.winner != "")][["season", "date", "winner", "match_id"]]
    # Natural-key reconciliation, never join the unrelated legacy numeric IDs.
    original_path = root / "archive/original_matches.csv"
    reconciliation = {}
    if original_path.exists():
        from .data import canonical_team
        old = pd.read_csv(original_path)
        def key(row):
            return (str(row["date"])[:10], *sorted([canonical_team(row["team1"]), canonical_team(row["team2"])]))
        new_keys = {key(row): row for row in matches.to_dict("records")}
        old_rows = old.to_dict("records")
        missing = [row for row in old_rows if key(row) not in new_keys]
        pd.DataFrame(missing, columns=old.columns).to_csv(root / "reports/legacy_unmatched_matches.csv", index=False)
        mismatches = []
        for row in old_rows:
            new = new_keys.get(key(row))
            if new is not None:
                old_winner = canonical_team(row["winner"]) if pd.notna(row["winner"]) else ""
                if old_winner != new["winner"]:
                    mismatches.append({"legacy_id": row["id"], "match_id": new["match_id"], "date": new["date"],
                                       "legacy_winner": old_winner, "source_winner": new["winner"]})
        pd.DataFrame(mismatches, columns=["legacy_id", "match_id", "date", "legacy_winner", "source_winner"]).to_csv(root / "reports/legacy_winner_differences.csv", index=False)
        reconciliation = {"legacy_rows": len(old), "matched_on_date_and_teams": len(old)-len(missing),
                          "unmatched_legacy_rows": len(missing), "winner_differences": len(mismatches)}
    for name, table in tables.items():
        table.to_csv(root / "reports" / f"{name}.csv", index=False)
    summary = {**manifest, "decided_matches": len(decided), "regulation_matches_for_chasing": len(regulation),
               "toss_winner_wins": int(decided.toss_match_win.sum()),
               "toss_winner_win_pct": round(100 * decided.toss_match_win.mean(), 2),
               "chase_wins": int(regulation.chase_win.sum()), "chase_win_pct": round(100 * regulation.chase_win.mean(), 2),
               "batting_leader": tables["batting_career"].iloc[0][["player", "runs"]].to_dict(),
               "bowling_leader": tables["bowling_career"].iloc[0][["player", "wickets"]].to_dict(),
               "reconciliation": reconciliation,
               "matches_flagged_missing_info": int(matches.missing_info.ne("[]").sum())}
    (root / "reports/summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return tables, summary
