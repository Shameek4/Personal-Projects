"""Portable HTML report; all charts are embedded, no network or server needed."""
import base64
from html import escape
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

BLUE, TEAL, GOLD = "#173b63", "#05857e", "#d48a14"


def make_report(root, tables, summary, metrics):
    chart_dir = root / "reports/charts"
    chart_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "axes.spines.top": False,
                         "axes.spines.right": False, "axes.labelcolor": "#374151", "axes.titleweight": "bold",
                         "figure.facecolor": "white", "axes.facecolor": "white"})
    charts = []

    def save(name, title, caption, plot):
        fig, ax = plt.subplots(figsize=(11, 6))
        plot(ax)
        ax.set_title(title, loc="left", pad=18)
        ax.grid(axis="x" if "barh" in name else "y", alpha=.13)
        ax.set_axisbelow(True)
        fig.tight_layout()
        path = chart_dir / f"{name}.png"
        fig.savefig(path, dpi=145, bbox_inches="tight")
        plt.close(fig)
        charts.append((path, title, caption))

    season = tables["season_summary"]
    save("season_coverage", "Nineteen seasons of IPL match records" if len(season) == 19 else "IPL match records by season",
         "Counts describe Cricsheet coverage, including matches without a winner; they are not official fixture totals.",
         lambda ax: (ax.bar(season.season.astype(str), season.matches, color=BLUE), ax.tick_params(axis="x", rotation=45), ax.set_ylabel("Matches in source")))
    team = tables["team_summary"].head(12).iloc[::-1]
    save("team_wins_barh", "Most wins across the source history", "Only genuine name changes are combined. Deccan Chargers and Sunrisers Hyderabad remain separate franchises.",
         lambda ax: (ax.barh(team.team, team.wins, color=TEAL), ax.set_xlabel("Match wins, including resolved ties")))
    batting = tables["batting_career"].head(10).iloc[::-1]
    save("batting_barh", "Leading run scorers", "Runs off the bat, excluding Super Overs; names follow Cricsheet's player registry.",
         lambda ax: (ax.barh(batting.player, batting.runs, color=BLUE), ax.set_xlabel("Runs")))
    bowling = tables["bowling_career"].head(10).iloc[::-1]
    save("bowling_barh", "Leading wicket takers", "Bowler-credited wickets only. Run outs, retired hurt/out and obstructing the field are excluded, as are Super Overs.",
         lambda ax: (ax.barh(bowling.player, bowling.wickets, color=TEAL), ax.set_xlabel("Wickets")))
    trend = tables["first_innings_trend"]
    save("scoring_trend", "First-innings scoring over time", "Unreduced scheduled 20-over innings that reached 120 legal balls or 10 wickets. A descriptive trend, not a causal estimate.",
         lambda ax: (ax.plot(trend.season, trend.average_runs, color=TEAL, marker="o", linewidth=2.5), ax.set_xticks(trend.season[::2]), ax.set_ylabel("Average first-innings runs")))
    phase = tables["phase_summary"]
    save("phase_scoring", "How scoring changes through an innings", "Fixed over bands: 1-6, 7-15 and 16-20. Excludes Super Overs and matches with a recorded D/L method; rain-adjusted powerplays are not inferred.",
         lambda ax: (ax.bar(phase.phase, phase.run_rate, color=[BLUE, TEAL, GOLD]), ax.set_ylabel("Runs per six legal balls")))
    def confusion(ax):
        values = metrics["confusion_matrix"]
        ax.imshow(values, cmap="Blues")
        for x in range(2):
            for y in range(2):
                ink = "white" if values[y][x] > (max(map(max, values)) + min(map(min, values))) / 2 else BLUE
                ax.text(x, y, str(values[y][x]), ha="center", va="center", fontsize=24, color=ink)
        ax.set_xticks([0, 1], ["Team 1 loses", "Team 1 wins"])
        ax.set_yticks([0, 1], ["Team 1 loses", "Team 1 wins"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
    save("confusion_matrix", f"Held-out {metrics['test_season']} predictions", "Team 1 is the alphabetically first canonical franchise name; the evaluation model was fitted before this season.", confusion)
    predictions = pd.read_csv(root / "reports/test_predictions.csv")
    predictions["bin"] = pd.cut(predictions.team1_probability, bins=[0, .2, .4, .6, .8, 1], include_lowest=True)
    calibration = predictions.groupby("bin", observed=True).agg(predicted=("team1_probability", "mean"), actual=("target", "mean"), n=("target", "size"))
    calibration.to_csv(root / "reports/calibration.csv")
    def calibration_plot(ax):
        ax.plot([0, 1], [0, 1], "--", color="#94a3b8")
        ax.plot(calibration.predicted, calibration.actual, marker="o", color=TEAL)
        for row in calibration.itertuples():
            ax.annotate(f"n={row.n}", (row.predicted, row.actual), xytext=(8, 8), textcoords="offset points")
        ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="Mean predicted probability", ylabel="Observed Team 1 win fraction")
    save("calibration", "Probability reliability on the held-out season", "Five fixed probability bins, with sample sizes. Small groups make calibration estimates uncertain.", calibration_plot)

    def table(frame, columns=None, limit=15):
        frame = frame if columns is None else frame[columns]
        return '<div class="table-scroll">' + frame.head(limit).to_html(index=False, border=0, na_rep="—", float_format=lambda v: f"{v:,.2f}") + '</div>'

    test, baseline = metrics["test"], metrics["baseline_test"]
    insight = (
        f"The selected {metrics['selected_model'].lower()} achieved {test['accuracy']:.1%} accuracy on "
        f"{test['matches']} decided matches in {metrics['test_season']}. The training-prior baseline achieved "
        f"{baseline['accuracy']:.1%}. Model log loss was {test['log_loss']:.3f}, versus {baseline['log_loss']:.3f} "
        "for the baseline (lower is better). This is a measured experimental result, not a guaranteed advantage."
    )
    def chart_block(entry):
        path, title, caption = entry
        encoded = base64.b64encode(path.read_bytes()).decode()
        return f'<figure><img src="data:image/png;base64,{encoded}" alt="{escape(title)}"><figcaption>{escape(caption)}</figcaption></figure>'

    metric_table = pd.DataFrame([
        {"Model": metrics["selected_model"], "Accuracy (%)": test["accuracy"]*100, "Log loss": test["log_loss"], "Brier score": test["brier_score"], "ROC AUC": test["roc_auc"]},
        {"Model": "Training-prior baseline", "Accuracy (%)": baseline["accuracy"]*100, "Log loss": baseline["log_loss"], "Brier score": baseline["brier_score"], "ROC AUC": baseline["roc_auc"]},
    ])
    rec = summary["reconciliation"]
    content = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>IPL Cricket Analytics | Research report</title>
<style>
:root{{--ink:#122b43;--muted:#5b6b7b;--teal:#05857e;--line:#dde6eb}}
*{{box-sizing:border-box}}body{{margin:0;background:#f3f6f8;color:var(--ink);font:16px/1.65 system-ui,Segoe UI,sans-serif}}
header{{background:#102f4b;color:white;padding:54px max(5vw,calc((100vw - 1180px)/2)) 48px;border-bottom:6px solid #18b5a4}}
.eyebrow{{font-size:12px;text-transform:uppercase;letter-spacing:2.5px;color:#79ded4;font-weight:700}}h1{{font-size:clamp(34px,5vw,58px);line-height:1.1;letter-spacing:-2px;margin:14px 0}}header p{{max-width:770px;color:#d2e2ed}}
main{{max-width:1180px;margin:auto;padding:32px 24px 70px}}nav{{display:flex;gap:20px;flex-wrap:wrap;margin-bottom:28px}}a{{color:#087e79}}nav a{{font-size:14px;font-weight:650}}
.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}}.metric,section{{background:white;border:1px solid var(--line);border-radius:12px;padding:25px}}.metric strong{{font-size:32px;display:block;line-height:1.2}}.metric span{{font-size:13px;color:var(--muted)}}section{{margin:25px 0;padding:32px}}h2{{font-size:28px;line-height:1.2;margin:0 0 18px}}h3{{font-size:21px;margin:28px 0 10px}}p{{max-width:960px}}.lead{{font-size:19px}}.note{{background:#edf7f6;padding:18px 22px;border-left:4px solid var(--teal);border-radius:3px}}
.chart-grid{{display:grid;grid-template-columns:1fr 1fr;gap:24px}}figure{{margin:18px 0}}img{{width:100%;height:auto;display:block}}figcaption{{font-size:12px;color:var(--muted);line-height:1.55;margin-top:9px}}.table-scroll{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;font-size:13px}}th{{text-align:left;background:#eff4f7;padding:12px;white-space:nowrap}}td{{padding:10px 12px;border-bottom:1px solid #e6edf1}}tbody tr:hover{{background:#f3faf9}}code{{background:#edf2f5;padding:2px 5px;border-radius:4px}}footer{{font-size:12px;color:var(--muted);padding-top:16px}}
@media(max-width:760px){{.metrics{{grid-template-columns:1fr 1fr}}.chart-grid{{grid-template-columns:1fr}}section{{padding:22px}}header{{padding:34px 24px}}main{{padding:24px 14px}}}}
@media print{{body{{background:white}}section{{break-inside:avoid}}nav{{display:none}}}}
</style></head><body>
<header><div class="eyebrow">Cricket / Data / Evidence</div><h1>IPL, in perspective.</h1>
<p class="lead">A reproducible analysis of match outcomes, player performance and post-toss win prediction across {len(summary['seasons'])} seasons.</p>
<p>Author: Shameek Vardhan Bhatt · Source coverage: {summary['coverage_start']} to {summary['coverage_end']} · Data: Cricsheet</p></header>
<main><nav><a href="#coverage">Coverage</a><a href="#teams">Teams &amp; toss</a><a href="#players">Players</a><a href="#scoring">Scoring</a><a href="#model">Prediction</a><a href="#methods">Methods &amp; sources</a></nav>
<div class="metrics"><div class="metric"><strong>{summary['matches']:,}</strong><span>Matches in source snapshot</span></div><div class="metric"><strong>{summary['delivery_events']:,}</strong><span>Delivery events, including extras</span></div><div class="metric"><strong>{len(summary['seasons'])}</strong><span>Seasons represented</span></div><div class="metric"><strong>{summary['matches_without_winner']}</strong><span>Matches without a winner</span></div></div>
<section id="coverage"><h2>01 / Coverage you can audit</h2><p>The original README claimed coverage through 2019, but its supplied CSV actually ended in 2016. This edition uses one consistent, attributed source for both match and ball-by-ball data, with raw files and checksums retained. No-result matches remain in the descriptive analysis and are excluded from winner-model training.</p>
<div class="note">These are records available from Cricsheet, not a claim that every scheduled fixture has ball-by-ball coverage. The last available match date in this snapshot is <b>{summary['coverage_end']}</b>.</div>
{chart_block(charts[0])}{table(tables['season_summary'], limit=30)}
<p>Legacy comparison: {rec.get('legacy_rows', 0)} original rows; {rec.get('matched_on_date_and_teams', 0)} matched by date and the two teams; {rec.get('unmatched_legacy_rows', 0)} unmatched rows; {rec.get('winner_differences', 0)} winner differences. Detailed exception files are included. Legacy numeric IDs are unrelated to Cricsheet IDs.</p></section>
<section id="teams"><h2>02 / Teams, toss and chasing</h2><p>The toss winner also won <b>{summary['toss_winner_win_pct']:.2f}%</b> of {summary['decided_matches']:,} decided matches. Chasing teams won <b>{summary['chase_win_pct']:.2f}%</b> of {summary['regulation_matches_for_chasing']:,} eligible regulation matches, excluding recorded rain-method results and tied/Super Over matches.</p>
<p>These are historical associations. Venue, opposition, conditions and era all influence the decision to chase, so the difference is not a causal effect of choosing to field.</p>
{chart_block(charts[1])}{table(tables['team_summary'], limit=25)}<h3>Toss decisions</h3>{table(tables['toss_summary'])}<h3>Most-used venues in the chasing comparison</h3>{table(tables['venue_summary'], limit=10)}</section>
<section id="players"><h2>03 / Player performance</h2><p><b>{escape(summary['batting_leader']['player'])}</b> leads the source's run totals with {summary['batting_leader']['runs']:,} runs; <b>{escape(summary['bowling_leader']['player'])}</b> leads bowler-credited wickets with {summary['bowling_leader']['wickets']:,}. Super Over events are excluded from these career totals.</p>
<div class="chart-grid">{chart_block(charts[2])}{chart_block(charts[3])}</div>
<h3>Batting leaders</h3>{table(tables['batting_career'], ['player','runs','balls','strike_rate','average','fours','sixes'], 10)}
<h3>Bowling leaders</h3>{table(tables['bowling_career'], ['player','wickets','legal_balls','conceded','economy','average'], 10)}
<p>Career and season-level tables for every recorded player are included as CSV files. Stable Cricsheet player IDs preserve identity across display-name changes.</p></section>
<section id="scoring"><h2>04 / Scoring patterns</h2>{chart_block(charts[4])}{chart_block(charts[5])}{table(tables['phase_summary'])}</section>
<section id="model"><h2>05 / Honest prediction evaluation</h2><p class="lead">{escape(insight)}</p>
{table(metric_table)}<p>Accuracy 95% Wilson interval: <b>{test['accuracy_ci95_low']:.1%}–{test['accuracy_ci95_high']:.1%}</b>. The interval is approximate and does not account for dependence between matches.</p>
<div class="note">Training: {metrics['train_seasons'][0]}–{metrics['train_seasons'][-1]} · Selection: {metrics['validation_season']} · Held-out test: {metrics['test_season']}. Candidate selection uses validation log loss. Model weights stay fixed throughout the test season; history features update only after earlier dates.</div>
<p>Inputs are the two teams, venue, toss outcome, batting order, earlier Elo ratings, last-ten-match win form, smoothed head-to-head history, scoring rates and experience. Current-match scores, player-of-match awards and winning margins never enter the predictor. Team-order mirroring ensures that swapping the teams reverses their probabilities.</p>
<div class="chart-grid">{chart_block(charts[6])}{chart_block(charts[7])}</div>
<h3>Validation comparison</h3>{table(pd.DataFrame(metrics['validation_candidates']))}
<p>Both an evaluated holdout model and a separate model refitted on all decided matches are included. Line-ups, injuries, player availability, pitch and weather forecasts are outside this model. Results should be treated as an educational benchmark.</p></section>
<section id="methods"><h2>06 / Methods, sources and limitations</h2>
<ul><li>Source: <a href="https://cricsheet.org/downloads/">Cricsheet IPL men's JSON download</a>, maintained by Stephen Rushe. <a href="https://cricsheet.org/format/json/">Format documentation</a>.</li>
<li>Data license: <a href="https://cricsheet.org/licensing/">Open Data Commons Attribution License 1.0</a>. Original archive and license notices are preserved; derived tables contain normalized names and calculated statistics.</li>
<li>Only actual renames are consolidated. Deccan Chargers, Sunrisers Hyderabad, Pune Warriors and Rising Pune Supergiant remain distinct. Raw team and venue labels remain available.</li>
<li>Missing cities remain “Unknown”; no cities are invented. {summary['missing_cities']} source match records lack a city. {summary['matches_flagged_missing_info']} matches carry source missing-information flags.</li>
<li>Delivery counts include wides and no-balls. Bowling economy uses legal balls; byes, leg-byes and penalty extras are excluded from bowler-conceded runs. Batting balls exclude wides. Innings-level penalties are retained separately.</li>
<li>Phase bands use fixed over numbers. Player averages are blank when there are no dismissals or wickets. Counts can differ from official career totals where source coverage differs.</li>
<li>Checks cover unique keys, participating winners, run/extras arithmetic and innings reconciliation. They establish internal consistency, not independent scorecard verification of every ball.</li></ul>
<p>Snapshot SHA-256: <code>{summary['source_sha256']}</code></p>
<p>Open the included notebook for the full analysis, or use <code>python run.py build</code> to recreate the data, report, charts and models from the included archive.</p></section>
<footer>IPL Cricket Analytics &amp; Win Prediction · An expanded version of the supplied project · Data attribution: Cricsheet / Stephen Rushe.</footer></main></body></html>"""
    (root / "reports/IPL_Analytics_Report.html").write_text(content, encoding="utf-8")
    md = f"""# IPL Cricket Analytics — findings

Author: Shameek Vardhan Bhatt

## Data
- {summary['matches']:,} Cricsheet matches, {summary['coverage_start']} to {summary['coverage_end']}.
- {summary['delivery_events']:,} delivery events; {summary['super_over_deliveries']} in Super Overs.
- {summary['decided_matches']:,} decided matches; {summary['matches_without_winner']} without a winner.
- {summary['missing_cities']} missing cities retained as Unknown.

## Findings
- Toss winner also won {summary['toss_winner_win_pct']:.2f}% of decided matches.
- Chasing teams won {summary['chase_win_pct']:.2f}% of {summary['regulation_matches_for_chasing']:,} eligible regulation matches.
- Leading run scorer in this source: {summary['batting_leader']['player']} ({summary['batting_leader']['runs']:,}).
- Leading wicket taker: {summary['bowling_leader']['player']} ({summary['bowling_leader']['wickets']:,}).

## Prediction
{insight}

Train through {metrics['train_seasons'][-1]}; select on {metrics['validation_season']}; test on {metrics['test_season']}.
Features only use information from earlier dates. Evaluation simulates post-toss, match-by-match use.
Approximate accuracy 95% interval: {test['accuracy_ci95_low']:.1%}–{test['accuracy_ci95_high']:.1%}.

## Interpretation
Historical associations do not establish the causal effect of the toss or batting order.
Cricsheet coverage is not the official fixture list. No-result fixtures without recorded play can be absent.
Player totals exclude Super Overs. Missing source information and legacy reconciliation exceptions are reported.
The model excludes line-ups, injuries, weather and pitch measurements. The refitted deployment model is distinct from the evaluated holdout model.

Data: [Cricsheet](https://cricsheet.org/downloads/), Stephen Rushe; [ODC-By 1.0](https://cricsheet.org/licensing/).
"""
    (root / "reports/FINDINGS.md").write_text(md, encoding="utf-8")
    return root / "reports/IPL_Analytics_Report.html"
