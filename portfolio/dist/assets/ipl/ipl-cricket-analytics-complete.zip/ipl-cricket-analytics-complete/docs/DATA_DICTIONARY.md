# Data dictionary

CSV files use UTF-8. `deliveries.csv.gz` is gzip compressed and readable directly with `pandas.read_csv`. Match IDs should be read as strings. Blank numerical ratios mean undefined, not zero. Missing match winners are blank. No-result records remain in `matches.csv`.

## Tables and keys

| File | Grain / key | Purpose |
| --- | --- | --- |
| matches.csv | match_id | Match metadata and outcomes |
| deliveries.csv.gz | match_id, innings, over, delivery_in_over | Every delivery event, including illegal deliveries |
| wickets.csv | delivery key + wicket_index | Every wicket/retirement event; preserves multiple events on a delivery |
| innings.csv | match_id, innings | Innings totals, legal balls, targets, penalties |
| players.csv | match_id, team, player_id | Players listed in each match by the source, including applicable replacements |
| model_features.csv | match_id | Earlier-history predictors and target; only the documented feature allowlist enters models |

## Match fields

`date`: first listed match date (ISO); `season`: IPL calendar year; `season_raw`: original source season label.
`team1`, `team2`: canonical alphabetically ordered participants; `team1_raw`, `team2_raw`: the source's original order.
`city`: source city (Bangalore → Bengaluru), or Unknown. `venue`: explicitly normalized ground label; `venue_raw`: source label.
`toss_winner`, `toss_decision`: reported toss. `winner`: match winner, including eliminator/bowl-out winner for resolved ties.
`result`: source tie/no-result value or normal. `method`: adjustment method, if reported.
`win_by_runs`, `win_by_wickets`: source margins; zero does not on its own imply a no-result.
`player_of_match`: source award names joined with ` | `; `stage`: source stage or League.
`scheduled_overs`, `balls_per_over`: source format. `missing_info`: JSON representation of source missing flags.
`batting_first`, `chasing_team`: derived from first normal innings, when present.
`has_super_over`: any innings flagged super_over. `data_version`: source schema version.

## Delivery fields

`over` is zero based. `delivery_in_over` is the one-based event sequence, including wides/no-balls; **not a legal-ball count or a decimal over value**.
`innings` is the one-based source innings sequence; `super_over` is independent of this sequence.
`batting_team`, `bowling_team`: canonical labels. `batter`, `bowler`, `non_striker`: source display names; `batter_id`, `bowler_id`: stable person IDs.
`batter_runs`, `extra_runs`, `total_runs`: delivery run components.
`wides`, `noballs`, `byes`, `legbyes`, `penalty`: extra types (runs).
`legal_ball`: 0/1; excludes wides and no-balls. `batter_ball`: 0/1; excludes wides.
`bowler_runs`: batter runs plus wides/no-ball extras. `team_wickets`: wicket events except retired hurt.
`bowler_wickets`: events credited to bowler. `four`, `six`: boundary indicators.
`phase`: fixed over bands, independent of official reduced-innings powerplay rules.

## Wicket fields

`player_out`, `player_id`, `kind`, `bowler`, `credited_to_bowler`; retirement events are retained. `wicket_index` is zero based within a delivery. Fielders remain in the raw JSON rather than a separate fielding analytics table.

## Innings fields

`runs` includes delivery totals plus `penalty_pre`/`penalty_post`. `legal_balls`, `wickets`, `batting_team`, `bowling_team` are aggregates.
`target_runs`, `target_overs` preserve the source target. Target overs are cricket over notation; do not treat 19.2 as 19.2 decimal overs.

## Derived features and reports

`target` = 1 when team1 won, 0 when team2 won, blank otherwise.
`toss_team1`, `team1_bats_first` are binary. `elo_diff`, `form_diff`, `h2h_diff`, `scoring_rate_diff`, `experience_diff` are team1 minus team2 (head-to-head is centered as described in Methodology).

`reports/` contains full career/season batting and bowling tables, team totals, season coverage, champions, toss/venue/phase summaries, first-innings trend, exact test predictions, validation metrics, calibration bins and model parameters.
Career/season player stats exclude Super Overs. All denominators and exceptions are defined in METHODOLOGY.md. `model_parameters.csv` contains either signed logistic coefficients (numeric inputs standardized) or random-forest impurity importances; these are not causal effects.
