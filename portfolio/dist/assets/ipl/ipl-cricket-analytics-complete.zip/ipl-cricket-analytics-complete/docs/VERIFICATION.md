# Verification of the delivered edition

Verified on 14 October 2026 with Python 3.12.14. Exact installed package versions are in `requirements-lock.txt`.

| Check | Result |
| --- | --- |
| End-to-end offline build from bundled raw archive | Passed |
| Source parsing | 1,243 match JSON files and 295,732 delivery events |
| Match/delivery key uniqueness and participant winners | Passed |
| Delivery runs, extras and innings-score reconciliation | Passed |
| Legacy reconciliation by match date and teams | 577/577 matched; zero winner differences |
| Automated tests | 8 passed |
| New notebook | All 12 code cells executed without errors; rich outputs saved |
| Test predictions reproduced from saved holdout model | Passed, within 1e-12 numerical tolerance |
| Team-order probability symmetry | Passed |
| Invalid input rejection and unseen venue handling | Passed |
| Charts | All eight generated and visually inspected |

The tests include cricket extras/wicket/penalty edge cases, actual franchise renames, tie eliminators and multiple wicket events, current/future/same-day outcome leakage, scoring-history timing, full source integrity, saved model reproducibility, and inference input handling.

The notebook was executed through `scripts/execute_notebook.py`, an in-process IPython runner, because this execution environment restricts local Jupyter kernel sockets. It preserves regular notebook code and display outputs. It does not require a running notebook server. JupyterLab launch and browser rendering of the HTML were not verified here; the report's eight embedded images and HTML structure were checked locally.

The prediction protocol trains through 2024, selects on 2025 and evaluates on 73 decided 2026 matches. The selected random forest scored 45.21% accuracy and 0.6867 log loss; these are the actual results, not a target or promised performance.

Internal validation does not establish independent ball-by-ball agreement with every official scorecard. Coverage and cricket conventions are documented in METHODOLOGY.md.
