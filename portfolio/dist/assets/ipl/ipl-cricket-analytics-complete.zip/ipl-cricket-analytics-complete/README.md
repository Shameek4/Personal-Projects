# IPL Cricket Analytics & Win Prediction

**Author: Shameek Vardhan Bhatt**

A complete, reproducible cricket analytics project using real online data from **Cricsheet**: match analysis, ball-by-ball player statistics, scoring patterns and an evaluated post-toss win predictor.

## Start here

**Open `reports/IPL_Analytics_Report.html` in a browser.** It includes the findings, eight charts, model evaluation, methodology and sources. No installation or internet is needed to read it.

For the code and outputs, open **`IPL_Cricket_Analytics.ipynb`**. The notebook has been executed and its results are saved.

## Included snapshot

| Item | Coverage |
| --- | --- |
| Source | Cricsheet men's IPL JSON archive |
| Retrieval date | 14 October 2026, Asia/Calcutta |
| Match dates | 18 April 2008 – 31 May 2026 |
| Seasons | 19 (2008–2026) |
| Matches | 1,243; 1,234 with a winner and 9 without |
| Delivery events | 295,732, including 175 Super Over events |
| Original CSV | 577 matches, actually 2008–2016 despite its README claiming 2008–2019 |
| Expansion | 666 additional matches, plus delivery/innings/wicket/player data |

Counts are **source coverage**, not a promise of every scheduled fixture. Unplayed/abandoned fixtures may have no ball-by-ball record. Exact provenance and checksum: `data/source_manifest.json`. All 577 original records match the source by date and participating teams, with no winner differences.

## What changed

- Added the real source snapshot and five normalized datasets, plus documented refresh tooling.
- Added career/season batting and bowling, team/venue/toss comparisons, phase scoring, first-innings trends and season champions.
- Corrected franchise identity: Deccan Chargers and Sunrisers Hyderabad are distinct; so are Pune Warriors and Rising Pune Supergiant.
- Kept no-results in coverage analysis and excluded them from winner training. Super Over handling and cricket denominators are explicit.
- Replaced arbitrary categorical number labels and the random split with one-hot encoding and chronological train/validation/test seasons.
- Added historical Elo, win/scoring form, head-to-head and experience features with no current-match or same-day leakage.
- Added model and baseline metrics, calibration, individual test predictions, saved models, tests and a portable HTML report.
- Preserved the original notebook, README and dataset under `archive/`.

## Findings from this snapshot

- Toss winner also won **51.38%** of 1,234 decided matches.
- Chasing teams won **54.39%** of 1,195 eligible regulation matches (excludes tied/Super Over and recorded rain-method results).
- Source career leaders, excluding Super Overs: **V Kohli, 9,336 runs**; **YS Chahal, 233 wickets**.
- Random forest was selected using 2025 validation log loss. On 73 decided 2026 matches, accuracy was **45.21%**, versus **42.47%** for the earlier-training-prior baseline. Log loss was **0.6867** versus **0.6946**. Accuracy's approximate 95% interval is **34.31–56.58%**.

Predictive performance is modest and uncertain. The result is a transparent educational benchmark. The model excludes actual lineups, injuries, weather and pitch forecasts. Historical toss/chasing associations do not establish causality.

## Run the project

Tested with **Python 3.12.14**. Use Python 3.12 for the closest reproduction.

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py build
.\.venv\Scripts\python.exe -m pytest -q
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py build
.venv/bin/python -m pytest -q
```

`build` runs offline using the included raw archive. It recreates processed data, analysis tables, charts, model files, predictions and report. The notebook is a separate entrypoint; rerun its cells if you want updated saved notebook outputs after refreshing data.

To update from the internet, use `python run.py refresh` with your environment's Python. This downloads a new archive and rebuilds the outputs. Coverage, model selection and evaluation seasons may change; the refreshed manifest is authoritative. The fixed snapshot numbers in this README describe the delivered edition.

For JupyterLab:

```bash
python -m pip install -r requirements-notebook.txt
python -m jupyterlab IPL_Cricket_Analytics.ipynb
```

Select the project environment as the kernel and run from the project directory. Notebook-generation source is in `scripts/create_notebook.py`; rerunning that script creates a clean, unexecuted notebook.

## Try a hypothetical match

```bash
python run.py predict --team1 "Mumbai Indians" --team2 "Chennai Super Kings" --venue "Wankhede Stadium" --toss-winner "Mumbai Indians" --toss-decision field
```

This uses the latest available history. Swapping the teams complements their probabilities. Invalid teams/toss inputs are rejected; unseen venues are flagged. This is a post-toss estimate, not a live-score or historical replay service.

## Files

```text
IPL_Cricket_Analytics.ipynb   Executed analysis notebook
run.py                      Build / refresh / predict entrypoint
requirements*.txt           Runtime and optional notebook dependencies
src/ipl_analytics/           Reusable data, analysis, model and report modules
data/raw/                   Original Cricsheet ZIP, notices and download receipt
data/processed/             Matches, compressed deliveries, wickets, innings,
                            player appearances and historical model features
data/source_manifest.json   Coverage, attribution and source checksum
reports/                    HTML report, findings, charts, summary CSVs,
                            validation/test metrics and match predictions
models/                     Evaluated holdout model and separate all-data refit
tests/                      Cricket arithmetic, leakage and prediction checks
docs/                       Methodology, data dictionary and verification
archive/                    Original user-supplied notebook, README and CSV
```

Read compressed deliveries directly: `pd.read_csv('data/processed/deliveries.csv.gz')`. Match IDs are Cricsheet identifiers and should be read as strings; they are not the original CSV's numeric IDs. Full field definitions are in `docs/DATA_DICTIONARY.md`.

## Source and data license

Data: **Cricsheet / Stephen Rushe**, [downloads](https://cricsheet.org/downloads/), [JSON format](https://cricsheet.org/format/json/). JSON data is licensed under the **Open Data Commons Attribution License 1.0**, as documented on [Cricsheet's licensing page](https://cricsheet.org/licensing/). Original notices are preserved in `data/raw/`; the derived tables normalize names and calculate statistics. No Cricsheet endorsement is implied.

The user's original author credit is retained. This expansion does not assign a new license to the user-supplied code or archival dataset.
