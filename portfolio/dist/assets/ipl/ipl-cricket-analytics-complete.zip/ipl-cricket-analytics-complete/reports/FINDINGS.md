# IPL Cricket Analytics — findings

Author: Shameek Vardhan Bhatt

## Data
- 1,243 Cricsheet matches, 2008-04-18 to 2026-05-31.
- 295,732 delivery events; 175 in Super Overs.
- 1,234 decided matches; 9 without a winner.
- 51 missing cities retained as Unknown.

## Findings
- Toss winner also won 51.38% of decided matches.
- Chasing teams won 54.39% of 1,195 eligible regulation matches.
- Leading run scorer in this source: V Kohli (9,336).
- Leading wicket taker: YS Chahal (233).

## Prediction
The selected random forest achieved 45.2% accuracy on 73 decided matches in 2026. The training-prior baseline achieved 42.5%. Model log loss was 0.687, versus 0.695 for the baseline (lower is better). This is a measured experimental result, not a guaranteed advantage.

Train through 2024; select on 2025; test on 2026.
Features only use information from earlier dates. Evaluation simulates post-toss, match-by-match use.
Approximate accuracy 95% interval: 34.3%–56.6%.

## Interpretation
Historical associations do not establish the causal effect of the toss or batting order.
Cricsheet coverage is not the official fixture list. No-result fixtures without recorded play can be absent.
Player totals exclude Super Overs. Missing source information and legacy reconciliation exceptions are reported.
The model excludes line-ups, injuries, weather and pitch measurements. The refitted deployment model is distinct from the evaluated holdout model.

Data: [Cricsheet](https://cricsheet.org/downloads/), Stephen Rushe; [ODC-By 1.0](https://cricsheet.org/licensing/).
