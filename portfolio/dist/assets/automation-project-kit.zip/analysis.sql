-- SQLite. Data loaded by analyze.py. Amounts in USD unless explicitly named revenue_millions_usd.
SELECT
 COUNT(*) AS opportunity_count,
 SUM(CASE WHEN deal_stage='Won' THEN close_value ELSE 0 END) AS won_revenue,
 100.0*SUM(CASE WHEN deal_stage='Won' THEN 1 ELSE 0 END)
   / NULLIF(SUM(CASE WHEN deal_stage IN ('Won','Lost') THEN 1 ELSE 0 END),0) AS win_rate_pct,
 SUM(CASE WHEN deal_stage IN ('Prospecting','Engaging') THEN list_price ELSE 0 END) AS estimated_open_pipeline,
 AVG(CASE WHEN deal_stage='Won' AND cycle_days>=0 THEN cycle_days END) AS avg_won_cycle_days
FROM opportunities;

SELECT region, COUNT(*) AS opportunities,
 SUM(CASE WHEN deal_stage='Won' THEN close_value ELSE 0 END) AS won_revenue
FROM opportunities GROUP BY region ORDER BY won_revenue DESC;

-- Synthetic campaign labels are demo-only, absent from the source CRM data.
SELECT demo_campaign,
 SUM(CASE WHEN deal_stage='Won' THEN 1 ELSE 0 END) AS won,
 SUM(CASE WHEN deal_stage='Won' THEN close_value ELSE 0 END) AS won_revenue
FROM opportunities GROUP BY demo_campaign;
