"""Reproduce the portfolio analytics with Python's standard library."""
from pathlib import Path
import csv, datetime, hashlib, json, sqlite3, re

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
OUT.mkdir(exist_ok=True)
def read(name):
    with (ROOT/'data'/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
accounts=read('accounts.csv');raw=read('sales_pipeline.csv')
prices={r['product']:int(r['sales_price']) for r in read('products.csv')}
regions={r['sales_agent']:r['regional_office'] for r in read('sales_teams.csv')}
leads=[];seen=set()
for a in accounts:
    key=re.sub(r'[^\w]','',a['account'].lower())
    if not key or key in seen:continue
    seen.add(key)
    a['sector']=a['sector'].replace('technolgy','technology')
    score=(40 if a['sector']=='technology' else 0)+(30 if int(a['employees'])>=500 else 0)+(20 if float(a['revenue'])>=250 else 0)+(10 if all(a[k] for k in ['sector','employees','revenue','office_location','year_established']) else 0)
    leads.append({**a,'fit_score':score,'priority':'Priority' if score>=70 else 'Nurture'})
write('qualified_leads.csv',sorted(leads,key=lambda a:(-a['fit_score'],a['account'])))
sources=['Organic search','Webinar','Referral','Outbound'];campaigns=['Product discovery','Partner program','Operations briefing']
rows=[]
for r in raw:
    product=r['product'].replace('GTXPro','GTX Pro')
    start=datetime.date.fromisoformat(r['engage_date']) if r['engage_date'] else None
    end=datetime.date.fromisoformat(r['close_date']) if r['close_date'] else None
    cycle=(end-start).days if end and start else None
    digest=int(hashlib.sha256(r['opportunity_id'].encode()).hexdigest()[:8],16)
    rows.append({**r,'product':product,'close_value':int(r['close_value']) if r['close_value'] else 0,'region':regions[r['sales_agent']],'list_price':prices[product],'cycle_days':cycle,'activity_date':r['close_date'] or r['engage_date'],'demo_source':sources[digest%4],'demo_campaign':campaigns[(digest//4)%3]})
write('opportunities_enriched.csv',rows)
con=sqlite3.connect(OUT/'analysis.sqlite')
fields=list(rows[0]);numeric={'close_value','list_price','cycle_days'}
con.execute('DROP TABLE IF EXISTS opportunities')
con.execute('CREATE TABLE opportunities ('+', '.join('"'+f+'" '+('REAL' if f in numeric else 'TEXT') for f in fields)+')')
con.executemany('INSERT INTO opportunities VALUES ('+','.join('?' for _ in fields)+')',([r[f] for f in fields] for r in rows));con.commit()
sql=(ROOT/'analysis.sql').read_text(encoding='utf-8').split(';')[0]
cur=con.execute(sql);metrics=dict(zip([x[0] for x in cur.description],cur.fetchone()))
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
con.close();print(json.dumps(metrics,indent=2))
