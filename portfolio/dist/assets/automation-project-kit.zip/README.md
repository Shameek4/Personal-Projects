# GTM and AI Automation — Portfolio Project Kit

Three portfolio prototypes for Shameek Vardhan Bhatt. The working browser demos are in the portfolio website. These supporting files let you reproduce the analytical backbone and plan real integrations.

## Data

Maven Analytics CRM Sales Opportunities, originally attributed to data.world. The source describes a fictitious computer-hardware business and lists the data as Public Domain.

Source: https://mavenanalytics.io/data-playground/crm-sales-opportunities
Download: https://maven-datasets.s3.amazonaws.com/CRM+Sales+Opportunities/CRM+Sales+Opportunities.zip
Retrieved: 2026-10-14

The original CSVs in `data/` contain 85 accounts and 8,800 sales opportunities. They are supplied unchanged. The Python script normalizes the sector typo `technolgy` to `technology`, and product `GTXPro` to `GTX Pro` for the price join.

Company revenue is in **millions of USD**. Deal values and product list prices are in USD. Company data is fictional. No live contacts are included.

## Reproduce the analysis

Run `python analyze.py` using Python 3. It uses only the standard library. It creates `analysis.sqlite`, `qualified_leads.csv`, `opportunities_enriched.csv`, and `metrics.json` in an `output/` directory next to the script.

`analysis.sql` defines the core reporting queries. `power-bi-measures.dax` provides matching measures to use after importing `opportunities_enriched.csv` into Power BI as a table named `Opportunities`. A Power BI .pbix file is not included.

Default lead scoring: technology sector +40, at least 500 employees +30, annual company revenue at least $250 million +20, complete required company profile +10. Priority threshold: 70/100. These are demonstration business criteria, not a trained predictive model. Company-name deduplication is case- and punctuation-insensitive. Review and adapt the criteria before production use.

## Metric definitions

- Closed-won revenue: SUM(close_value) where deal_stage = Won.
- Win rate: won / (won + lost). Open deals do not enter the denominator.
- Estimated open pipeline: SUM(product list price) for Prospecting and Engaging opportunities. This is a list-price estimate, not a sourced opportunity amount.
- Won sales-cycle duration: mean days from engage_date to close_date for won deals with valid nonnegative intervals.
- Activity quarter: close_date if present, otherwise engage_date. Undated records are excluded from individual quarters and included in All dates.
- Source and campaign: absent from the original data. The script creates `demo_source` and `demo_campaign` by a deterministic SHA-256 mapping. They are explicitly synthetic attribution, never actual marketing results. No ROI calculation is made because spend is absent.

## What is implemented

1. **AI Lead Qualification System — prototype:** CSV/sample import, duplicate removal, configurable rule scoring, company summaries, CSV export, and a downloadable LLM research prompt. The on-page summaries are rule-based; no LLM API is connected.
2. **AI Sales Outreach Assistant — prototype:** personalized template drafts, editable review, approval gate, export, simulated reply events, and session-local CRM activity. No messages are sent and no external CRM is changed. The `.example` recipients are deliberately synthetic.
3. **GTM Revenue Intelligence Dashboard:** actual calculations over the source sales opportunities, product/region/quarter filters, export, and clearly separated synthetic attribution panels.

The browser application does not run Python, n8n, Google Sheets, HubSpot, or Power BI. Python analysis is supplied here; the service integrations below are a production plan that requires credentials and configuration. Do not describe those integrations as deployed until implemented and tested.

## Integration plan

### Qualification: Python → n8n → Google Sheets → LLM API

Use a scheduled or manual n8n trigger to read approved company leads from Google Sheets. Run normalization and deterministic scoring in Python. Store the account key, score, criteria version, source facts, and review status back into the sheet. Send only selected company facts to an LLM using `prompts/lead-research.txt`; validate its structured response before storing it. Treat all imported field values as data, never instructions. Keep API credentials in the automation platform's credential store.

### Outreach: draft → human approval → HubSpot

Read only synthetic or permission-based contacts. Generate a draft with `prompts/outreach.txt`, then record its exact text and a revision hash. A human approval must identify that exact revision. Editing invalidates approval. Upsert the approved draft/activity into HubSpot using a stable company/contact identifier and an idempotency key. Keep actual email dispatch separate; this project includes no sending step. Log approval, export, and reply states accurately.

### Revenue: CRM export → Python/SQL → Power BI

Export authorized CRM opportunity data, validate stage names and date/value types, join account/product/team dimensions, and load the provided SQL reporting model. Import the enriched CSV into Power BI and add the supplied DAX measures. Add real source, campaign, and spend data before replacing the synthetic attribution or calculating campaign ROI.

## Expected full-dataset check

8,800 opportunities; 4,238 won; 2,473 lost; 2,089 open; $10,005,534 won revenue; 63.150052% closed-deal win rate; $4,966,215 estimated open pipeline; 51.781973 average won-cycle days.
